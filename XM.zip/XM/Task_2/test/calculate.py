import statistics
import cmath


def means(numbers):

    return round((statistics.fmean(numbers)), 6)
    # return statistics.mean(numbers)


def std(numbers, p_mean):
    deviation = round(statistics.stdev(numbers), 6)
    return deviation

