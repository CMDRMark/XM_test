from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.routing import APIRoute
from datetime import datetime
import csv
import asyncio
import random


class LoggedRoute(APIRoute):
    def get_route_handler(self):
        original_route_handler = super().get_route_handler()

        async def custom_route_handler(request):
            response = await original_route_handler(request)
            with open("log.csv", "a") as f:
                writer = csv.writer(f, delimiter=";")
                writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), request.method, request.url, response.status_code])
            return response
        return custom_route_handler


def log_request_and_response(req, resp):
    with open("log.csv", "a") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), req.method, req.url, resp.status_code])


router = APIRouter(route_class=LoggedRoute)


@router.get('/')  # first handler for successful connection
async def index():
    return {"message": "Hi. You've successfully connected to the API."}


@router.get('/people/{people_id}')  # handler for getting people information by id
async def get_people(people_id: int):
    await asyncio.sleep(random.uniform(0.2, 0.8))
    if people_id in range(1, 101):
        response = {
            "name": "Luke Skywalker",
            "height": "172",
            "mass": "77",
            "hair_color": "blond",
            "skin_color": "fair",
            "eye_color": "blue",
            "birth_year": "19BBY",
            "gender": "male",
            "homeworld": "some planet",
            "films": [
                "too",
                "many",
                "to",
                "remember",
                "I like Star Trek more anyway"
            ],
            "species": "hooman",
            "vehicles": "spacebike",
            "starships": "Melenium Falcon i guess ",
            "planet": '127.0.0.1:8000/planets/1',
                   }
    else:
        response = HTTPException(status_code=404, detail="Id of person not found. Please check the id and try again. Id must be between 1 and 100.")
        raise response
    return response


@router.get('/planets/{planet_id}/')  # handler for getting planet information by id
async def get_planet(planet_id: int):
    await asyncio.sleep(random.uniform(0.2, 0.8))
    if planet_id in range(1, 101):
        response = {
            "name": "Earth",
            "rotation_period": "24",
            "orbital_period": "365",
            "diameter": "12500",
            "climate": "changing quickly",
            "gravity": "1 standard",
            "terrain": "mostly wet land",
            "population": "too many to count",
        }
    else:
        response = HTTPException(status_code=404, detail="Id of planet not found. Please check the id and try again. Id must be between 1 and 100.")
        raise response
    return response


@router.get('/starships/{spaceship_id}/')  # handler for getting spaceship information by id
async def get_spaceship(spaceship_id: int):
    await asyncio.sleep(random.uniform(0.2, 0.8))
    if spaceship_id in range(1, 101):
        response = {
            "name": "BMW 520i",
            "model": "Series 5",
            "manufacturer": "BMW",
            "cost_in_credits": "500000000",
            "length": "4.8",
            "max_atmosphering_speed": "100",
            "crew": "1",
            "passengers": "up to 4, with a maximum of 6",
            "cargo_capacity": "10000000 grams",
            "consumables": "1 year",
            "hyperdrive_rating": "1.0",
            "starship_class": "Starfighter",
        }
    else:
        response = HTTPException(status_code=404, detail="Id of starship not found. Please check the id and try again. Id must be between 1 and 100.")
        raise response
    return response
