import statistics


def mean(numbers: list) -> float:
    return statistics.mean(numbers)


def std(numbers: list) -> float:
    return statistics.stdev(numbers)
