1. To run tests, you must specify directory of XM_1/Task_1 folder on 84th row of robo_main.robot file.
2. Run test by entering "robot robo_main.robot" in command line. --either specify absolute path to robot file or cd to the robot file and then enter above command.
